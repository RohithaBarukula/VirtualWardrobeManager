#include "../include/OutfitPlanner.h"
#include <iostream>
#include <fstream>
#include <sstream>

void OutfitPlanner::planOutfitForDay(const std::string &day, const std::vector<ClothingItem*> &outfit) {
    weeklyPlan[day] = outfit;
}

void OutfitPlanner::viewWeeklyPlan() const {
    for (const auto &dayPlan : weeklyPlan) {
        std::cout << dayPlan.first << ":\n";
        for (const auto *item : dayPlan.second) {
            std::cout << "- " << item->getName() << "\n";
        }
    }
}

void OutfitPlanner::saveWeeklyPlan(const std::string &filename) const {
    std::ofstream outFile(filename);
    if (!outFile) {
        std::cerr << "Error opening file for saving weekly plan.\n";
        return;
    }

    for (const auto &dayPlan : weeklyPlan) {
        outFile << dayPlan.first << ":";
        for (const auto *item : dayPlan.second) {
            outFile << item->getName() << ",";
        }
        outFile << "\n";
    }

    outFile.close();
}

void OutfitPlanner::loadWeeklyPlan(const std::string &filename, WardrobeManager &wardrobe) {
    std::ifstream inFile(filename);
    if (!inFile) {
        std::cerr << "Error opening file for loading weekly plan.\n";
        return;
    }

    std::string line;
    while (std::getline(inFile, line)) {
        std::istringstream iss(line);
        std::string day;
        if (std::getline(iss, day, ':')) {
            std::vector<ClothingItem*> outfit;
            std::string itemName;
            while (std::getline(iss, itemName, ',')) {
                ClothingItem* item = wardrobe.getItem(itemName);
                if (item) {
                    outfit.push_back(item);
                    item->incrementUsage(); // Increment usage count
                }
            }
            weeklyPlan[day] = outfit;
        }
    }

    inFile.close();
}
