#include "../include/WardrobeManager.h"
#include <iostream>
#include <fstream>

void WardrobeManager::addItem(const std::string &name, ClothingItem::Category category) {
    items.emplace_back(name, category);
}

void WardrobeManager::viewItemsByCategory(ClothingItem::Category category) const {
    for (const auto &item : items) {
        if (item.getCategory() == category) {
            std::cout << item.getName() << " (Worn " << item.getUsageCount() << " times)\n";
        }
    }
}

ClothingItem* WardrobeManager::getItem(const std::string &name) {
    for (auto &item : items) {
        if (item.getName() == name) {
            return &item;
        }
    }
    return nullptr;
}

void WardrobeManager::removeItem(const std::string &name) {
    auto it = std::remove_if(items.begin(), items.end(),
                             [&name](const ClothingItem &item) { return item.getName() == name; });

    if (it != items.end()) {
        items.erase(it, items.end());
        std::cout << "Item '" << name << "' removed from wardrobe.\n";
    } else {
        std::cout << "Item '" << name << "' not found in wardrobe.\n";
    }
}

void WardrobeManager::saveToFile(const std::string &filename) const {
    std::ofstream outFile(filename);
    if (!outFile) {
        std::cerr << "Error opening file for saving.\n";
        return;
    }

    for (const auto &item : items) {
        outFile << item.getName() << " "
                << item.getCategory() << " "
                << item.getUsageCount() << "\n";
    }

    outFile.close();
}

void WardrobeManager::loadFromFile(const std::string &filename) {
    std::ifstream inFile(filename);
    if (!inFile) {
        std::cerr << "Error opening file for loading.\n";
        return;
    }

    std::string name;
    int category;
    int usageCount;

    while (inFile >> name >> category >> usageCount) {
        ClothingItem item(name, static_cast<ClothingItem::Category>(category));
        for (int i = 0; i < usageCount; ++i) {
            item.incrementUsage();
        }
        items.push_back(item);
    }

    inFile.close();
}
