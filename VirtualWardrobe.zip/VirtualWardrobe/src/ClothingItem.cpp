#include "../include/ClothingItem.h"

ClothingItem::ClothingItem(const std::string &name, Category category)
    : name(name), category(category), usageCount(0) {}

std::string ClothingItem::getName() const { return name; }

ClothingItem::Category ClothingItem::getCategory() const { return category; }

int ClothingItem::getUsageCount() const { return usageCount; }

void ClothingItem::incrementUsage() { ++usageCount; }
