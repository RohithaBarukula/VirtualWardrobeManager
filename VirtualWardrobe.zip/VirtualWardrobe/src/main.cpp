#include "../include/ClothingItem.h"
#include "../include/WardrobeManager.h"
#include "../include/OutfitPlanner.h"
#include <iostream>

// Function to display category options and get user input
ClothingItem::Category selectCategory() {
    int choice;
    std::cout << "Select a category:\n";
    std::cout << "1. Top\n";
    std::cout << "2. Bottom\n";
    std::cout << "3. Accessory\n";
    std::cout << "4. Footwear\n";
    std::cout << "Enter your choice: ";
    std::cin >> choice;

    switch (choice) {
        case 1: return ClothingItem::TOP;
        case 2: return ClothingItem::BOTTOM;
        case 3: return ClothingItem::ACCESSORY;
        case 4: return ClothingItem::FOOTWEAR;
        default:
            std::cout << "Invalid choice. Defaulting to Top.\n";
            return ClothingItem::TOP;
    }
}

// Function to add a new item to the wardrobe
void addItemToWardrobe(WardrobeManager &wardrobe) {
    std::string name;
    std::cout << "Enter the name of the item: ";
    std::cin.ignore(); // Clear any leftover input
    std::getline(std::cin, name);

    ClothingItem::Category category = selectCategory();
    wardrobe.addItem(name, category);
    std::cout << "Item '" << name << "' added to wardrobe.\n";
}

// Function to remove an item from the wardrobe
void removeItemFromWardrobe(WardrobeManager &wardrobe) {
    std::string name;
    std::cout << "Enter the name of the item to remove: ";
    std::cin.ignore();
    std::getline(std::cin, name);
    wardrobe.removeItem(name);
}

int main() {
    WardrobeManager wardrobe;
    OutfitPlanner planner;

    // Load wardrobe and weekly plan data
    wardrobe.loadFromFile("wardrobe_data.txt");
    planner.loadWeeklyPlan("weekly_plan.txt", wardrobe);

    int choice;
    do {
        std::cout << "\n--- Virtual Wardrobe ---\n";
        std::cout << "1. Add new item\n";
        std::cout << "2. Remove an item\n";
        std::cout << "3. View items by category\n";
        std::cout << "4. Plan outfit for a day\n";
        std::cout << "5. View weekly outfit plan\n";
        std::cout << "6. Save and exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                addItemToWardrobe(wardrobe);
                break;
            case 2:
                removeItemFromWardrobe(wardrobe);
                break;
            case 3: {
                int category;
                std::cout << "Enter category (0=Top, 1=Bottom, 2=Accessory, 3=Footwear): ";
                std::cin >> category;
                wardrobe.viewItemsByCategory(static_cast<ClothingItem::Category>(category));
                break;
            }
            case 4: {
                std::string day;
                std::cout << "Enter the day: ";
                std::cin >> day;
                std::vector<ClothingItem*> outfit;

                std::string itemName;
                std::cout << "Enter item names for " << day << " (type 'done' to finish):\n";
                while (true) {
                    std::cin >> itemName;
                    if (itemName == "done") break;
                    ClothingItem* item = wardrobe.getItem(itemName);
                    if (item) {
                        outfit.push_back(item);
                    } else {
                        std::cout << "Item not found.\n";
                    }
                }

                planner.planOutfitForDay(day, outfit);
                break;
            }
            case 5:
                planner.viewWeeklyPlan();
                break;
            case 6:
                // Save data before exiting
                wardrobe.saveToFile("wardrobe_data.txt");
                planner.saveWeeklyPlan("weekly_plan.txt");
                std::cout << "Data saved. Exiting...\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 6);

    return 0;
}
