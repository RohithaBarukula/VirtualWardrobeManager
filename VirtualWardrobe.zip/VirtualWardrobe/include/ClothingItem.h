#ifndef CLOTHING_ITEM_H
#define CLOTHING_ITEM_H

#include <string>

class ClothingItem {
public:
    enum Category { TOP, BOTTOM, ACCESSORY, FOOTWEAR };

    ClothingItem(const std::string &name, Category category);

    std::string getName() const;
    Category getCategory() const;
    int getUsageCount() const;
    void incrementUsage();

private:
    std::string name;
    Category category;
    int usageCount;
};

#endif
