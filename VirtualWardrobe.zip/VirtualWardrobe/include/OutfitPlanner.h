#ifndef OUTFIT_PLANNER_H
#define OUTFIT_PLANNER_H

#include "ClothingItem.h"
#include <map>
#include <string>
#include <vector>
#include "WardrobeManager.h"

class OutfitPlanner {
public:
    void planOutfitForDay(const std::string &day, const std::vector<ClothingItem*> &outfit);
    void viewWeeklyPlan() const;

    void saveWeeklyPlan(const std::string &filename) const;
    void loadWeeklyPlan(const std::string &filename, WardrobeManager &wardrobe);

private:
    std::map<std::string, std::vector<ClothingItem*>> weeklyPlan;
};

#endif
