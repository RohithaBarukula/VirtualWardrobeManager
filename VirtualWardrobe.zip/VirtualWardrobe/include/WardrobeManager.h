#ifndef WARDROBE_MANAGER_H
#define WARDROBE_MANAGER_H

#include "ClothingItem.h"
#include <vector>
#include <map>
#include <string>

class WardrobeManager {
public:
    void addItem(const std::string &name, ClothingItem::Category category);
    void viewItemsByCategory(ClothingItem::Category category) const;
    ClothingItem* getItem(const std::string &name);
    void removeItem(const std::string &name);

    void saveToFile(const std::string &filename) const;
    void loadFromFile(const std::string &filename);

private:
    std::vector<ClothingItem> items;
};

#endif
